# Teknoir Label Studio SDK

k port-forward svc/label-studio 8080:80
GOOGLE_APPLICATION_CREDENTIALS=$(pwd)/teknoir-admin-credentials.json GOOGLE_CLOUD_PROJECT=teknoir python import_ppe.py

LABEL_STUDIO_URL=http://localhost:8080 GOOGLE_APPLICATION_CREDENTIALS=$(pwd)/teknoir-admin-credentials.json GOOGLE_CLOUD_PROJECT=teknoir python teknoir-labelstudio-sdk.py